Entity-alias review sample comparison
Sample: campaign:likely_front:sample
Proposal: campaign:likely_front:proposal
Matched: 12  Adjudicated: 0  Comparable: 0
Agreement: 0  Disagreement: 0  Agreement rate: n/a
Proposal reject precision: n/a
Proposal rejects: 12  Hits: 0  False positives: 0
Confidence: high=12
