Entity-alias review assist: 400 items (from 406 open)
Groups: 261  Batches: 17  Batch size: 25
Filters: relations=disjoint  source_pair=claude-history-memory <> claude-local-session-memory
Relations: disjoint=400
Top source pairs: claude-history-memory <> claude-local-session-memory=400

entity-alias-batch-001  items=23  groups=6
  anchors: chapters, extension, involuntary, von, 000, checklist

entity-alias-batch-002  items=24  groups=8
  anchors: coast, collision, com, comprehensive, const, continue, deleuze, error

entity-alias-batch-003  items=24  groups=8
  anchors: family, format, fre, horror, infrastructure, its, layout, models

entity-alias-batch-004  items=24  groups=8
  anchors: parallel, personal, platforms, positioning, reminders, rok, scale, settings

entity-alias-batch-005  items=25  groups=11
  anchors: thumbnail, tool, training, 2026, alerts, apparatus, apr, astronomical, athamas, attention, block

entity-alias-batch-006  items=24  groups=12
  anchors: book, care, classical, coin, commander, component, construction, costs, covenant, cowork, duration, engineering

entity-alias-batch-007  items=24  groups=12
  anchors: entity, everything, f32, feature, film, free, gaps, genres, governance, guest, guide, horace

entity-alias-batch-008  items=24  groups=12
  anchors: house, ino, install, manga, mar, missing, month, ndi, neumorphic, nothing, omni orchestrate, operations

entity-alias-batch-009  items=24  groups=12
  anchors: page, pathways, plato, points, portfolio, reference, rendering, retention, ritual, rust, show, signatures

entity-alias-batch-010  items=25  groups=13
  anchors: storyline, storylines, string, structure, tarantino, test, these, timeline, verify, works, workspace, youtube, 255

entity-alias-batch-011  items=25  groups=25
  anchors: across, added, adult, apps, arca, architectural, artie, artist, beat, bob, business, caller, cascade, cce, chats, codemiko, collective, color, command, communications, complete, compound, compute, core, cost

entity-alias-batch-012  items=25  groups=25
  anchors: csv, cube, date, day, deck, depth, docs, documented, due, encoding, essay, etc, filter, finger, finite, firebase, forever, form, fragmented, functions, genre, git, goal, google, hardware

entity-alias-batch-013  items=25  groups=25
  anchors: helix, home, host, identity, implement, integration, interior, jan, json, knowledge, kubrick, lanes, learning, lfo, lifestyle, live, local, loop, machina, martian, max, mckee, memory, might, miko

entity-alias-batch-014  items=25  groups=25
  anchors: minimal, mobile, mocap, mode, name, names, narratological, node, numbers, obs, omni dromenon, omni pe, ontological, orbs, orchestration, other, output, outputs, paradoxes, participation, paste, path, pattern, peer, per

entity-alias-batch-015  items=25  groups=25
  anchors: philosophical, pieces, placeholder, planets, player, procurement, prs, quantum, recording, recursive, referenced, requirements, response, roles, root, run, sample, scales, sexy, shatter, sleek, software, space, specs, standards

entity-alias-batch-016  items=25  groups=25
  anchors: stern, strategy, symbols, table, technique, tendrils, text, theory, therefore, threads, through, time, toolkit, track, txt, unexpected, use, using, value, var, version, visualization, web, websites, week

entity-alias-batch-017  items=9  groups=9
  anchors: weights, while, window, wisdom, world, would, yet, zodiac, zzzxy

Top groups:
- chapters  items=5  max_score=0.83  relations=disjoint=5
  labels: Bharata-Muni's narrative principles as algorithms, Chapters, Missing, Primary, Remaining
  example: Chapters <> Bharata-Muni's narrative principles as algorithms [disjoint]
  hint: Lexical evidence is weak; this likely needs rejection unless external context clearly links the entities.
- extension  items=4  max_score=0.83  relations=disjoint=4
  labels: Com, Extension, Invalid network egress hostname patterns, Network, Settings
  example: Extension <> Invalid network egress hostname patterns [disjoint]
  hint: Lexical evidence is weak; this likely needs rejection unless external context clearly links the entities.
- involuntary  items=4  max_score=0.83  relations=disjoint=4
  labels: Attention, Attention economy across media forms, Horror, Involuntary, Jazz
  example: Involuntary <> Attention [disjoint]
  hint: Lexical evidence is weak; this likely needs rejection unless external context clearly links the entities.
- von  items=4  max_score=0.83  relations=disjoint=4
  labels: Both, Deleuze, Philosophical frameworks for reciprocal performance, Von, Whitehead
  example: Von <> Philosophical frameworks for reciprocal performance [disjoint]
  hint: Lexical evidence is weak; this likely needs rejection unless external context clearly links the entities.
- 000  items=3  max_score=0.83  relations=disjoint=3
  labels: 000, Income, Medicaid, Research report from document inquiry
  example: 000 <> Research report from document inquiry [disjoint]
  hint: Lexical evidence is weak; this likely needs rejection unless external context clearly links the entities.
- checklist  items=3  max_score=1.00  relations=disjoint=3
  labels: Checklist, Ctr, Retention, Thumbnail
  example: Checklist <> Retention [disjoint]
  hint: Queue score is high despite disjoint labels; inspect upstream context before accepting.
- coast  items=3  max_score=1.00  relations=disjoint=3
  labels: Coast, Ghost, Show, Space
  example: Coast <> Ghost [disjoint]
  hint: Queue score is high despite disjoint labels; inspect upstream context before accepting.
- collision  items=3  max_score=0.86  relations=disjoint=3
  labels: Collision, David's comedic rules as narratological algorithms, Storyline, Storylines
  example: Collision <> David's comedic rules as narratological algorithms [disjoint]
  hint: Lexical evidence is weak; this likely needs rejection unless external context clearly links the entities.
- com  items=3  max_score=0.83  relations=disjoint=3
  labels: Com, Invalid network egress hostname patterns, Network, Settings
  example: Com <> Invalid network egress hostname patterns [disjoint]
  hint: Lexical evidence is weak; this likely needs rejection unless external context clearly links the entities.
- comprehensive  items=3  max_score=0.86  relations=disjoint=3
  labels: Annotated, Claude project manifest with annotated bibliography, Comprehensive, Risk
  example: Comprehensive <> Annotated [disjoint]
  hint: Lexical evidence is weak; this likely needs rejection unless external context clearly links the entities.
... 251 more groups
