Entity-alias reject stage
Project: /Users/4jp/Workspace/organvm-i-theoria/conversation-corpus-engine
Stage status: blocked  Ready to apply: False
Candidates: 0
Rollup adjudicated: 0  Reject precision: n/a
Thresholds: min_reject_precision=95.00%  min_adjudicated=20
Blocked:
- Need at least 20 adjudicated samples; found 0.
- Proposal reject precision is not yet measurable for the selected packets.
