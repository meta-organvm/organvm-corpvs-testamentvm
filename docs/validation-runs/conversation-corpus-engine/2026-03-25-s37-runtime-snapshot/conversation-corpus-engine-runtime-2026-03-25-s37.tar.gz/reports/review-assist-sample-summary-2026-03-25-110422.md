Entity-alias review sample summary
Source: /Users/4jp/Workspace/organvm-i-theoria/conversation-corpus-engine/reports/review-assist-sample-latest.md
Samples: 12  Adjudicated: 0  Decisive: 0
Reject precision: n/a
Confirmed rejects: 0  False positives: 0  Needs context: 0  Pending: 12
Packet: scope=400 filtered / 406 open  buckets=likely-reject  sampled_groups=12
Buckets: likely-reject=12

- chapters  bucket=likely-reject  proposed=reject  manual=pending
- collision  bucket=likely-reject  proposed=reject  manual=pending
- family  bucket=likely-reject  proposed=reject  manual=pending
- parallel  bucket=likely-reject  proposed=reject  manual=pending
- thumbnail  bucket=likely-reject  proposed=reject  manual=pending
- extension  bucket=likely-reject  proposed=reject  manual=pending
- com  bucket=likely-reject  proposed=reject  manual=pending
- format  bucket=likely-reject  proposed=reject  manual=pending
- personal  bucket=likely-reject  proposed=reject  manual=pending
- tool  bucket=likely-reject  proposed=reject  manual=pending
... 2 more samples
