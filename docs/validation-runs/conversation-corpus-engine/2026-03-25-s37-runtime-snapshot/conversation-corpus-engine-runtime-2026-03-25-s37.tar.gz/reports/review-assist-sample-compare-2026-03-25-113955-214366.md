Entity-alias review sample comparison
Sample: /Users/4jp/Workspace/organvm-i-theoria/conversation-corpus-engine/reports/review-assist-sample-2026-03-25-113955-087698.md
Proposal: /Users/4jp/Workspace/organvm-i-theoria/conversation-corpus-engine/reports/review-assist-sample-proposal-2026-03-25-113955-153880.json
Matched: 12  Adjudicated: 0  Comparable: 0
Agreement: 0  Disagreement: 0  Agreement rate: n/a
Proposal reject precision: n/a
Proposal rejects: 12  Hits: 0  False positives: 0
Confidence: high=12
