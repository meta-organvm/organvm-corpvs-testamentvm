Entity-alias review assist: 23 items (from 400 filtered / 406 open)
Groups: 6  Batches: 1  Batch size: 25
Selected batch: entity-alias-batch-001 (1/17)
Filters: relations=disjoint
Relations: disjoint=23
Top source pairs: claude-history-memory <> claude-local-session-memory=23

entity-alias-batch-001  items=23  groups=6
  anchors: chapters, extension, involuntary, von, 000, checklist

Top groups:
- chapters  items=5  max_score=0.83  relations=disjoint=5
  bucket: likely-reject
  flags: has-low-specificity-labels, all-zero-overlap
  labels: Bharata-Muni's narrative principles as algorithms, Chapters, Missing, Primary, Remaining
  example: Chapters <> Bharata-Muni's narrative principles as algorithms [disjoint]
  hint: Lexical evidence is weak; this likely needs rejection unless external context clearly links the entities.
  review: Reject unless external context ties these labels to the same entity.
  review: Spot-check the top-scoring pair before closing the whole group.
  review: Verify labels are not headings, placeholders, fragments, or extraction residue.
- extension  items=4  max_score=0.83  relations=disjoint=4
  bucket: likely-reject
  flags: has-low-specificity-labels, all-zero-overlap
  labels: Com, Extension, Invalid network egress hostname patterns, Network, Settings
  example: Extension <> Invalid network egress hostname patterns [disjoint]
  hint: Lexical evidence is weak; this likely needs rejection unless external context clearly links the entities.
  review: Reject unless external context ties these labels to the same entity.
  review: Spot-check the top-scoring pair before closing the whole group.
  review: Verify labels are not headings, placeholders, fragments, or extraction residue.
- involuntary  items=4  max_score=0.83  relations=disjoint=4
  bucket: likely-reject
  flags: all-zero-overlap
  labels: Attention, Attention economy across media forms, Horror, Involuntary, Jazz
  example: Involuntary <> Attention [disjoint]
  hint: Lexical evidence is weak; this likely needs rejection unless external context clearly links the entities.
  review: Reject unless external context ties these labels to the same entity.
  review: Spot-check the top-scoring pair before closing the whole group.
- von  items=4  max_score=0.83  relations=disjoint=4
  bucket: likely-reject
  flags: has-low-specificity-labels, all-zero-overlap
  labels: Both, Deleuze, Philosophical frameworks for reciprocal performance, Von, Whitehead
  example: Von <> Philosophical frameworks for reciprocal performance [disjoint]
  hint: Lexical evidence is weak; this likely needs rejection unless external context clearly links the entities.
  review: Reject unless external context ties these labels to the same entity.
  review: Spot-check the top-scoring pair before closing the whole group.
  review: Verify labels are not headings, placeholders, fragments, or extraction residue.
- 000  items=3  max_score=0.83  relations=disjoint=3
  bucket: likely-reject
  flags: has-low-specificity-labels, all-zero-overlap
  labels: 000, Income, Medicaid, Research report from document inquiry
  example: 000 <> Research report from document inquiry [disjoint]
  hint: Lexical evidence is weak; this likely needs rejection unless external context clearly links the entities.
  review: Reject unless external context ties these labels to the same entity.
  review: Spot-check the top-scoring pair before closing the whole group.
  review: Verify labels are not headings, placeholders, fragments, or extraction residue.
- checklist  items=3  max_score=1.00  relations=disjoint=3
  bucket: needs-context
  flags: has-low-specificity-labels, has-high-score-disjoint-pairs, all-zero-overlap
  labels: Checklist, Ctr, Retention, Thumbnail
  example: Checklist <> Retention [disjoint]
  hint: Queue score is high despite disjoint labels; inspect upstream context before accepting.
  review: Inspect the highest-scoring pair before rejecting; upstream signal is stronger than lexical overlap.
  review: Reject only if the pair still reads like neighboring topics rather than the same entity.
  review: Verify labels are not headings, placeholders, fragments, or extraction residue.
