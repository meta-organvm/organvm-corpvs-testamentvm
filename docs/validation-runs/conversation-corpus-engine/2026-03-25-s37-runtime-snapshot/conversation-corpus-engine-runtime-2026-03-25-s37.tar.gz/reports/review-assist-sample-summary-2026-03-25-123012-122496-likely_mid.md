Entity-alias review sample summary
Source: campaign:likely_mid:sample
Samples: 12  Adjudicated: 0  Decisive: 0
Reject precision: n/a
Confirmed rejects: 0  False positives: 0  Needs context: 0  Pending: 12
Packet: scope=400 filtered / 406 open  buckets=likely-reject  sampled_groups=12
Buckets: likely-reject=12

- book  bucket=likely-reject  proposed=reject  manual=pending
- entity  bucket=likely-reject  proposed=reject  manual=pending
- house  bucket=likely-reject  proposed=reject  manual=pending
- page  bucket=likely-reject  proposed=reject  manual=pending
- storyline  bucket=likely-reject  proposed=reject  manual=pending
- classical  bucket=likely-reject  proposed=reject  manual=pending
- everything  bucket=likely-reject  proposed=reject  manual=pending
- ino  bucket=likely-reject  proposed=reject  manual=pending
- pathways  bucket=likely-reject  proposed=reject  manual=pending
- storylines  bucket=likely-reject  proposed=reject  manual=pending
... 2 more samples
