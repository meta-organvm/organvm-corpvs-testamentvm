Entity-alias review apply plan
Project: /Users/4jp/Workspace/organvm-i-theoria/conversation-corpus-engine
Apply status: disabled  Enabled: False
Candidates: 0
Blocked:
- Apply plan remains disabled until reject-stage becomes ready.
- Need at least 20 adjudicated samples; found 0.
- Proposal reject precision is not yet measurable for the selected packets.
Snapshots:
- review-queue: /Users/4jp/Workspace/organvm-i-theoria/conversation-corpus-engine/state/federated-review-queue.json -> /Users/4jp/Workspace/organvm-i-theoria/conversation-corpus-engine/reports/review-assist-apply-plan-pre-apply-queue.json
- review-decisions: /Users/4jp/Workspace/organvm-i-theoria/conversation-corpus-engine/state/federated-canonical-decisions.json -> /Users/4jp/Workspace/organvm-i-theoria/conversation-corpus-engine/reports/review-assist-apply-plan-pre-apply-decisions.json
- review-history: /Users/4jp/Workspace/organvm-i-theoria/conversation-corpus-engine/state/federated-review-history.json -> /Users/4jp/Workspace/organvm-i-theoria/conversation-corpus-engine/reports/review-assist-apply-plan-pre-apply-history.json
Rollback:
- restore state files from snapshots
- rebuild federation artifacts
- verify queue/history counts match the snapshot baseline
