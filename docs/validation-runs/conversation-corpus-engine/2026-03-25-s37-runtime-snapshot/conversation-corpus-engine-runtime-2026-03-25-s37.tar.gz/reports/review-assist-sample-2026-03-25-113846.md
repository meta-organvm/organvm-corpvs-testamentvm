# Entity-alias review sample

- Items: 18
- Groups: 8
- Scope: 400 filtered / 406 open
- Candidate groups: 22
- Candidate batches: 10
- Sampled groups: 8
- Buckets: needs-context

## Sample 1: checklist
- Bucket: needs-context
- Flags: has-low-specificity-labels, has-high-score-disjoint-pairs, all-zero-overlap
- Labels: Checklist, Ctr, Retention, Thumbnail
- Review IDs: federated-entity-alias-claude-history-memory-entity-checklist-claude-local-session-memory-entity-retent, federated-entity-alias-claude-history-memory-entity-checklist-claude-local-session-memory-entity-ctr, federated-entity-alias-claude-history-memory-entity-checklist-claude-local-session-memory-entity-thumbn
- Example: Checklist <> Retention [disjoint] score=1.00
- Proposed outcome: reject
- Manual outcome: 
- Notes: 
- Review: Inspect the highest-scoring pair before rejecting; upstream signal is stronger than lexical overlap.
- Review: Reject only if the pair still reads like neighboring topics rather than the same entity.
- Review: Verify labels are not headings, placeholders, fragments, or extraction residue.

## Sample 2: coast
- Bucket: needs-context
- Flags: has-high-score-disjoint-pairs, all-zero-overlap
- Labels: Coast, Ghost, Show, Space
- Review IDs: federated-entity-alias-claude-history-memory-entity-coast-claude-local-session-memory-entity-ghost, federated-entity-alias-claude-history-memory-entity-coast-claude-local-session-memory-entity-space, federated-entity-alias-claude-history-memory-entity-coast-claude-local-session-memory-entity-show
- Example: Coast <> Ghost [disjoint] score=1.00
- Proposed outcome: reject
- Manual outcome: 
- Notes: 
- Review: Inspect the highest-scoring pair before rejecting; upstream signal is stronger than lexical overlap.
- Review: Reject only if the pair still reads like neighboring topics rather than the same entity.

## Sample 3: alerts
- Bucket: needs-context
- Flags: has-high-score-disjoint-pairs, all-zero-overlap
- Labels: Alerts, Coin, make sleek and sexy and hip --- 786-Bounce Crypto Alert Platform – All-In-One Spec 1. Project Overview Build a cross-...
- Review IDs: federated-entity-alias-claude-history-memory-entity-alerts-claude-local-session-memory-entity-make-slee, federated-entity-alias-claude-history-memory-entity-alerts-claude-local-session-memory-entity-coin
- Example: Alerts <> make sleek and sexy and hip --- 786-Bounce Crypto Alert Platform – All-In-One Spec 1. Project Overview Build a cross-... [disjoint] score=0.94
- Proposed outcome: reject
- Manual outcome: 
- Notes: 
- Review: Inspect the highest-scoring pair before rejecting; upstream signal is stronger than lexical overlap.
- Review: Reject only if the pair still reads like neighboring topics rather than the same entity.

## Sample 4: care
- Bucket: needs-context
- Flags: has-low-specificity-labels, has-high-score-disjoint-pairs, all-zero-overlap
- Labels: Care, Dog, Girls
- Review IDs: federated-entity-alias-claude-history-memory-entity-care-claude-local-session-memory-entity-dog, federated-entity-alias-claude-history-memory-entity-care-claude-local-session-memory-entity-girls
- Example: Care <> Dog [disjoint] score=1.00
- Proposed outcome: reject
- Manual outcome: 
- Notes: 
- Review: Inspect the highest-scoring pair before rejecting; upstream signal is stronger than lexical overlap.
- Review: Reject only if the pair still reads like neighboring topics rather than the same entity.
- Review: Verify labels are not headings, placeholders, fragments, or extraction residue.

## Sample 5: feature
- Bucket: needs-context
- Flags: has-low-specificity-labels, has-high-score-disjoint-pairs, all-zero-overlap
- Labels: Feature, Memorial, Pet
- Review IDs: federated-entity-alias-claude-history-memory-entity-feature-claude-local-session-memory-entity-pet, federated-entity-alias-claude-history-memory-entity-feature-claude-local-session-memory-entity-memorial
- Example: Feature <> Pet [disjoint] score=1.00
- Proposed outcome: reject
- Manual outcome: 
- Notes: 
- Review: Inspect the highest-scoring pair before rejecting; upstream signal is stronger than lexical overlap.
- Review: Reject only if the pair still reads like neighboring topics rather than the same entity.
- Review: Verify labels are not headings, placeholders, fragments, or extraction residue.

## Sample 6: manga
- Bucket: needs-context
- Flags: has-high-score-disjoint-pairs, all-zero-overlap
- Labels: Anime, Japanese, Manga
- Review IDs: federated-entity-alias-claude-history-memory-entity-manga-claude-local-session-memory-entity-anime, federated-entity-alias-claude-history-memory-entity-manga-claude-local-session-memory-entity-japanese
- Example: Manga <> Anime [disjoint] score=1.00
- Proposed outcome: reject
- Manual outcome: 
- Notes: 
- Review: Inspect the highest-scoring pair before rejecting; upstream signal is stronger than lexical overlap.
- Review: Reject only if the pair still reads like neighboring topics rather than the same entity.

## Sample 7: plato
- Bucket: needs-context
- Flags: has-high-score-disjoint-pairs, all-zero-overlap
- Labels: Narratological, Plato, Republic
- Review IDs: federated-entity-alias-claude-history-memory-entity-plato-claude-local-session-memory-entity-narratolog, federated-entity-alias-claude-history-memory-entity-plato-claude-local-session-memory-entity-republic
- Example: Plato <> Narratological [disjoint] score=1.00
- Proposed outcome: reject
- Manual outcome: 
- Notes: 
- Review: Inspect the highest-scoring pair before rejecting; upstream signal is stronger than lexical overlap.
- Review: Reject only if the pair still reads like neighboring topics rather than the same entity.

## Sample 8: string
- Bucket: needs-context
- Flags: has-high-score-disjoint-pairs, all-zero-overlap
- Labels: **Conversation Overview** The user requested a comprehensive development handoff document for "Samsara's River," an integrated psychological healing and wisdom cultivation platform. This sophisticated system combines four main components: the Samsara Simulator (nicknamed "Danger Room") for interactive relationship pattern recognition, River Journal for adaptive multi-dimensional wisdom journaling, Observer Protocol as a metacognitive awareness layer, and Integration Bridge connecting pattern work with wisdom practices. The user provided extensive technical specifications covering system architecture, data models, implementation priorities, styling guidelines, API specifications, testing strategies, and deployment considerations. The platform is designed to adapt content in real-time based on user emotional state, spiritual orientation, intellectual depth preferences, current patterns, and cultural context. Key technical features include a "fold system" for adaptive content layers, depth dial controls for complexity adjustment, 3D visualization using Three.js, local-first data storage with IndexedDB, and Claude API integration for AI-powered insights. The system emphasizes privacy and safety with features like panic button functionality, crisis detection, and sanctuary mode for vulnerable users. The handoff document outlines a four-phase development approach starting with foundation architecture, followed by building the Danger Room MVP, River Journal MVP, and finally the integration layer. The user specified critical ethical safeguards including crisis detection, privacy protection measures, and trauma-informed design principles. The document includes detailed TypeScript interfaces, React component examples, CSS styling patterns, database schemas, and testing specifications to guide implementation of this complex therapeutic technology platform., Pattern, String
- Review IDs: federated-entity-alias-claude-history-memory-entity-string-claude-local-session-memory-entity-conversat, federated-entity-alias-claude-history-memory-entity-string-claude-local-session-memory-entity-pattern
- Example: String <> **Conversation Overview** The user requested a comprehensive development handoff document for "Samsara's River," an integrated psychological healing and wisdom cultivation platform. This sophisticated system combines four main components: the Samsara Simulator (nicknamed "Danger Room") for interactive relationship pattern recognition, River Journal for adaptive multi-dimensional wisdom journaling, Observer Protocol as a metacognitive awareness layer, and Integration Bridge connecting pattern work with wisdom practices. The user provided extensive technical specifications covering system architecture, data models, implementation priorities, styling guidelines, API specifications, testing strategies, and deployment considerations. The platform is designed to adapt content in real-time based on user emotional state, spiritual orientation, intellectual depth preferences, current patterns, and cultural context. Key technical features include a "fold system" for adaptive content layers, depth dial controls for complexity adjustment, 3D visualization using Three.js, local-first data storage with IndexedDB, and Claude API integration for AI-powered insights. The system emphasizes privacy and safety with features like panic button functionality, crisis detection, and sanctuary mode for vulnerable users. The handoff document outlines a four-phase development approach starting with foundation architecture, followed by building the Danger Room MVP, River Journal MVP, and finally the integration layer. The user specified critical ethical safeguards including crisis detection, privacy protection measures, and trauma-informed design principles. The document includes detailed TypeScript interfaces, React component examples, CSS styling patterns, database schemas, and testing specifications to guide implementation of this complex therapeutic technology platform. [disjoint] score=0.99
- Proposed outcome: reject
- Manual outcome: 
- Notes: 
- Review: Inspect the highest-scoring pair before rejecting; upstream signal is stronger than lexical overlap.
- Review: Reject only if the pair still reads like neighboring topics rather than the same entity.
