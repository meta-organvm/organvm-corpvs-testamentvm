Entity-alias review sample proposal
Source: /Users/4jp/Workspace/organvm-i-theoria/conversation-corpus-engine/reports/review-assist-sample-2026-03-25-113955-509034.md
Samples: 12
Packet: scope=400 filtered / 406 open  buckets=likely-reject  sampled_groups=12
Assistant outcomes: reject=12
Assistant confidence: high=12

- across  bucket=likely-reject  assistant=reject  confidence=high
  rationale: Group is already classified as likely-reject.
  rationale: Lexical overlap is absent across the sampled pairs.
- csv  bucket=likely-reject  assistant=reject  confidence=high
  rationale: Group is already classified as likely-reject.
  rationale: Lexical overlap is absent across the sampled pairs.
  rationale: At least one label looks like a heading, fragment, placeholder, or extraction residue.
- helix  bucket=likely-reject  assistant=reject  confidence=high
  rationale: Group is already classified as likely-reject.
  rationale: Lexical overlap is absent across the sampled pairs.
- minimal  bucket=likely-reject  assistant=reject  confidence=high
  rationale: Group is already classified as likely-reject.
  rationale: Lexical overlap is absent across the sampled pairs.
- philosophical  bucket=likely-reject  assistant=reject  confidence=high
  rationale: Group is already classified as likely-reject.
  rationale: Lexical overlap is absent across the sampled pairs.
- added  bucket=likely-reject  assistant=reject  confidence=high
  rationale: Group is already classified as likely-reject.
  rationale: Lexical overlap is absent across the sampled pairs.
- cube  bucket=likely-reject  assistant=reject  confidence=high
  rationale: Group is already classified as likely-reject.
  rationale: Lexical overlap is absent across the sampled pairs.
- home  bucket=likely-reject  assistant=reject  confidence=high
  rationale: Group is already classified as likely-reject.
  rationale: Lexical overlap is absent across the sampled pairs.
- mobile  bucket=likely-reject  assistant=reject  confidence=high
  rationale: Group is already classified as likely-reject.
  rationale: Lexical overlap is absent across the sampled pairs.
- pieces  bucket=likely-reject  assistant=reject  confidence=high
  rationale: Group is already classified as likely-reject.
  rationale: Lexical overlap is absent across the sampled pairs.
- adult  bucket=likely-reject  assistant=reject  confidence=high
  rationale: Group is already classified as likely-reject.
  rationale: Lexical overlap is absent across the sampled pairs.
- date  bucket=likely-reject  assistant=reject  confidence=high
  rationale: Group is already classified as likely-reject.
  rationale: Lexical overlap is absent across the sampled pairs.
