# Entity-alias review sample

- Items: 12
- Groups: 12
- Scope: 400 filtered / 406 open
- Candidate groups: 114
- Candidate batches: 5
- Sampled groups: 12
- Batch offset: 10
- Buckets: likely-reject

## Sample 1: across
- Bucket: likely-reject
- Flags: all-zero-overlap
- Labels: Across, Cross-document connection discovery
- Review IDs: federated-entity-alias-claude-history-memory-entity-across-claude-local-session-memory-entity-cross-doc
- Example: Across <> Cross-document connection discovery [disjoint] score=0.75
- Proposed outcome: reject
- Manual outcome: 
- Notes: 
- Review: Reject unless external context ties these labels to the same entity.
- Review: Spot-check the top-scoring pair before closing the whole group.

## Sample 2: csv
- Bucket: likely-reject
- Flags: has-low-specificity-labels, all-zero-overlap
- Labels: Advanced debugging strategy, Csv
- Review IDs: federated-entity-alias-claude-history-memory-entity-csv-claude-local-session-memory-entity-advanced-deb
- Example: Csv <> Advanced debugging strategy [disjoint] score=0.75
- Proposed outcome: reject
- Manual outcome: 
- Notes: 
- Review: Reject unless external context ties these labels to the same entity.
- Review: Spot-check the top-scoring pair before closing the whole group.
- Review: Verify labels are not headings, placeholders, fragments, or extraction residue.

## Sample 3: helix
- Bucket: likely-reject
- Flags: all-zero-overlap
- Labels: Helical Shape Description, Helix
- Review IDs: federated-entity-alias-claude-history-memory-entity-helix-claude-local-session-memory-entity-helical-sh
- Example: Helix <> Helical Shape Description [disjoint] score=0.75
- Proposed outcome: reject
- Manual outcome: 
- Notes: 
- Review: Reject unless external context ties these labels to the same entity.
- Review: Spot-check the top-scoring pair before closing the whole group.

## Sample 4: minimal
- Bucket: likely-reject
- Flags: all-zero-overlap
- Labels: Dashboard Design Modernization, Minimal
- Review IDs: federated-entity-alias-claude-history-memory-entity-minimal-claude-local-session-memory-entity-dashboar
- Example: Minimal <> Dashboard Design Modernization [disjoint] score=0.75
- Proposed outcome: reject
- Manual outcome: 
- Notes: 
- Review: Reject unless external context ties these labels to the same entity.
- Review: Spot-check the top-scoring pair before closing the whole group.

## Sample 5: philosophical
- Bucket: likely-reject
- Flags: all-zero-overlap
- Labels: Multiversal poly-algorithm conceptual manifesto, Philosophical
- Review IDs: federated-entity-alias-claude-history-memory-entity-philosophical-claude-local-session-memory-entity-mu
- Example: Philosophical <> Multiversal poly-algorithm conceptual manifesto [disjoint] score=0.80
- Proposed outcome: reject
- Manual outcome: 
- Notes: 
- Review: Reject unless external context ties these labels to the same entity.
- Review: Spot-check the top-scoring pair before closing the whole group.

## Sample 6: added
- Bucket: likely-reject
- Flags: all-zero-overlap
- Labels: Added, PowerShell Profile Enhancement
- Review IDs: federated-entity-alias-claude-history-memory-entity-added-claude-local-session-memory-entity-powershell
- Example: Added <> PowerShell Profile Enhancement [disjoint] score=0.75
- Proposed outcome: reject
- Manual outcome: 
- Notes: 
- Review: Reject unless external context ties these labels to the same entity.
- Review: Spot-check the top-scoring pair before closing the whole group.

## Sample 7: cube
- Bucket: likely-reject
- Flags: all-zero-overlap
- Labels: AI Design Directive Framework, Cube
- Review IDs: federated-entity-alias-claude-history-memory-entity-cube-claude-local-session-memory-entity-ai-design-d
- Example: Cube <> AI Design Directive Framework [disjoint] score=0.80
- Proposed outcome: reject
- Manual outcome: 
- Notes: 
- Review: Reject unless external context ties these labels to the same entity.
- Review: Spot-check the top-scoring pair before closing the whole group.

## Sample 8: home
- Bucket: likely-reject
- Flags: all-zero-overlap
- Labels: Git repository commit, Home
- Review IDs: federated-entity-alias-claude-history-memory-entity-home-claude-local-session-memory-entity-git-reposit
- Example: Home <> Git repository commit [disjoint] score=0.75
- Proposed outcome: reject
- Manual outcome: 
- Notes: 
- Review: Reject unless external context ties these labels to the same entity.
- Review: Spot-check the top-scoring pair before closing the whole group.

## Sample 9: mobile
- Bucket: likely-reject
- Flags: all-zero-overlap
- Labels: 3D Divine Comedy Visualization, Mobile
- Review IDs: federated-entity-alias-claude-history-memory-entity-mobile-claude-local-session-memory-entity-3d-divine
- Example: Mobile <> 3D Divine Comedy Visualization [disjoint] score=0.80
- Proposed outcome: reject
- Manual outcome: 
- Notes: 
- Review: Reject unless external context ties these labels to the same entity.
- Review: Spot-check the top-scoring pair before closing the whole group.

## Sample 10: pieces
- Bucket: likely-reject
- Flags: all-zero-overlap
- Labels: ASCII Art Consonant-Vowel Puzzle, Pieces
- Review IDs: federated-entity-alias-claude-history-memory-entity-pieces-claude-local-session-memory-entity-ascii-art
- Example: Pieces <> ASCII Art Consonant-Vowel Puzzle [disjoint] score=0.80
- Proposed outcome: reject
- Manual outcome: 
- Notes: 
- Review: Reject unless external context ties these labels to the same entity.
- Review: Spot-check the top-scoring pair before closing the whole group.

## Sample 11: adult
- Bucket: likely-reject
- Flags: all-zero-overlap
- Labels: Adult, Multi-camera reality TV streaming platform design
- Review IDs: federated-entity-alias-claude-history-memory-entity-adult-claude-local-session-memory-entity-multi-came
- Example: Adult <> Multi-camera reality TV streaming platform design [disjoint] score=0.86
- Proposed outcome: reject
- Manual outcome: 
- Notes: 
- Review: Reject unless external context ties these labels to the same entity.
- Review: Spot-check the top-scoring pair before closing the whole group.

## Sample 12: date
- Bucket: likely-reject
- Flags: all-zero-overlap
- Labels: Date, Document conversion sheet
- Review IDs: federated-entity-alias-claude-history-memory-entity-date-claude-local-session-memory-entity-document-co
- Example: Date <> Document conversion sheet [disjoint] score=0.75
- Proposed outcome: reject
- Manual outcome: 
- Notes: 
- Review: Reject unless external context ties these labels to the same entity.
- Review: Spot-check the top-scoring pair before closing the whole group.
