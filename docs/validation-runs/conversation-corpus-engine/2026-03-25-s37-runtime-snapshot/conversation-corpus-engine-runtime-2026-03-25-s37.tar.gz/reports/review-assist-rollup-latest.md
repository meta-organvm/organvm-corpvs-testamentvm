Entity-alias review rollup
Project: /Users/4jp/Workspace/organvm-i-theoria/conversation-corpus-engine
Indexed packets: 11  Selected: 11  Compared: 5
Matched samples: 52  Adjudicated: 0  Comparable: 0
Agreement: 0  Disagreement: 0  Agreement rate: n/a
Proposal reject precision: n/a
Statuses: pending=11
Scenarios: legacy=7, likely_front=1, likely_late=1, likely_mid=1, needs_context=1
Confidence: high=36, medium=16

- 2026-03-25-105452  status=pending  samples=12  adjudicated=0  scenario=legacy
- 2026-03-25-113845  status=pending  samples=12  adjudicated=0  scenario=legacy
- 2026-03-25-113846  status=pending  samples=8  adjudicated=0  scenario=legacy
  compare: /Users/4jp/Workspace/organvm-i-theoria/conversation-corpus-engine/reports/review-assist-sample-compare-2026-03-25-113846.json
- 2026-03-25-113955-087698  status=pending  samples=12  adjudicated=0  scenario=legacy
- 2026-03-25-113955-292340  status=pending  samples=12  adjudicated=0  scenario=legacy
- 2026-03-25-113955-509034  status=pending  samples=12  adjudicated=0  scenario=legacy
- 2026-03-25-113955-712523  status=pending  samples=8  adjudicated=0  scenario=legacy
- 2026-03-25-123012-122496-likely_front  status=pending  samples=12  adjudicated=0  scenario=likely_front
  compare: /Users/4jp/Workspace/organvm-i-theoria/conversation-corpus-engine/reports/review-assist-sample-compare-2026-03-25-123012-122496-likely_front.json
- 2026-03-25-123012-122496-likely_late  status=pending  samples=12  adjudicated=0  scenario=likely_late
  compare: /Users/4jp/Workspace/organvm-i-theoria/conversation-corpus-engine/reports/review-assist-sample-compare-2026-03-25-123012-122496-likely_late.json
- 2026-03-25-123012-122496-likely_mid  status=pending  samples=12  adjudicated=0  scenario=likely_mid
  compare: /Users/4jp/Workspace/organvm-i-theoria/conversation-corpus-engine/reports/review-assist-sample-compare-2026-03-25-123012-122496-likely_mid.json
- 2026-03-25-123012-122496-needs_context  status=pending  samples=8  adjudicated=0  scenario=needs_context
  compare: /Users/4jp/Workspace/organvm-i-theoria/conversation-corpus-engine/reports/review-assist-sample-compare-2026-03-25-123012-122496-needs_context.json
