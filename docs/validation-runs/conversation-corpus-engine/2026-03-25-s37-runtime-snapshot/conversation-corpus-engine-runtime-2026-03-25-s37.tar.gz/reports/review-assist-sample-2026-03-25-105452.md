# Entity-alias review sample

- Items: 40
- Groups: 12
- Scope: 400 filtered / 406 open
- Candidate groups: 36
- Candidate batches: 5
- Sampled groups: 12
- Buckets: likely-reject

## Sample 1: chapters
- Bucket: likely-reject
- Flags: has-low-specificity-labels, all-zero-overlap
- Labels: Bharata-Muni's narrative principles as algorithms, Chapters, Missing, Primary, Remaining, Supplement
- Review IDs: federated-entity-alias-claude-history-memory-entity-chapters-claude-local-session-memory-entity-bharata, federated-entity-alias-claude-history-memory-entity-chapters-claude-local-session-memory-entity-missing, federated-entity-alias-claude-history-memory-entity-chapters-claude-local-session-memory-entity-primary
- Example: Chapters <> Bharata-Muni's narrative principles as algorithms [disjoint] score=0.83
- Proposed outcome: reject
- Manual outcome: 
- Notes: 
- Review: Reject unless external context ties these labels to the same entity.
- Review: Spot-check the top-scoring pair before closing the whole group.
- Review: Verify labels are not headings, placeholders, fragments, or extraction residue.

## Sample 2: collision
- Bucket: likely-reject
- Flags: all-zero-overlap
- Labels: Collision, David's comedic rules as narratological algorithms, Storyline, Storylines
- Review IDs: federated-entity-alias-claude-history-memory-entity-collision-claude-local-session-memory-entity-david, federated-entity-alias-claude-history-memory-entity-collision-claude-local-session-memory-entity-storyl, federated-entity-alias-claude-history-memory-entity-collision-claude-local-session-memory-entity-storyl
- Example: Collision <> David's comedic rules as narratological algorithms [disjoint] score=0.86
- Proposed outcome: reject
- Manual outcome: 
- Notes: 
- Review: Reject unless external context ties these labels to the same entity.
- Review: Spot-check the top-scoring pair before closing the whole group.

## Sample 3: family
- Bucket: likely-reject
- Flags: has-low-specificity-labels, all-zero-overlap
- Labels: Family, Fre, Rok, Script analysis for open view draft
- Review IDs: federated-entity-alias-claude-history-memory-entity-family-claude-local-session-memory-entity-script-an, federated-entity-alias-claude-history-memory-entity-family-claude-local-session-memory-entity-fre, federated-entity-alias-claude-history-memory-entity-family-claude-local-session-memory-entity-rok
- Example: Family <> Script analysis for open view draft [disjoint] score=0.86
- Proposed outcome: reject
- Manual outcome: 
- Notes: 
- Review: Reject unless external context ties these labels to the same entity.
- Review: Spot-check the top-scoring pair before closing the whole group.
- Review: Verify labels are not headings, placeholders, fragments, or extraction residue.

## Sample 4: parallel
- Bucket: likely-reject
- Flags: all-zero-overlap
- Labels: Parallel, Touring, Transforming content into growth opportunities, Years
- Review IDs: federated-entity-alias-claude-history-memory-entity-parallel-claude-local-session-memory-entity-transfo, federated-entity-alias-claude-history-memory-entity-parallel-claude-local-session-memory-entity-touring, federated-entity-alias-claude-history-memory-entity-parallel-claude-local-session-memory-entity-years
- Example: Parallel <> Transforming content into growth opportunities [disjoint] score=0.83
- Proposed outcome: reject
- Manual outcome: 
- Notes: 
- Review: Reject unless external context ties these labels to the same entity.
- Review: Spot-check the top-scoring pair before closing the whole group.

## Sample 5: thumbnail
- Bucket: likely-reject
- Flags: has-low-specificity-labels, all-zero-overlap
- Labels: Ctr, HokageChess video checklist for retention and visibility, Retention, Thumbnail
- Review IDs: federated-entity-alias-claude-history-memory-entity-thumbnail-claude-local-session-memory-entity-hokage, federated-entity-alias-claude-history-memory-entity-thumbnail-claude-local-session-memory-entity-retent, federated-entity-alias-claude-history-memory-entity-thumbnail-claude-local-session-memory-entity-ctr
- Example: Thumbnail <> HokageChess video checklist for retention and visibility [disjoint] score=0.88
- Proposed outcome: reject
- Manual outcome: 
- Notes: 
- Review: Reject unless external context ties these labels to the same entity.
- Review: Spot-check the top-scoring pair before closing the whole group.
- Review: Verify labels are not headings, placeholders, fragments, or extraction residue.

## Sample 6: extension
- Bucket: likely-reject
- Flags: has-low-specificity-labels, all-zero-overlap
- Labels: Com, Extension, Invalid network egress hostname patterns, Network, Settings
- Review IDs: federated-entity-alias-claude-history-memory-entity-extension-claude-local-session-memory-entity-invali, federated-entity-alias-claude-history-memory-entity-extension-claude-local-session-memory-entity-networ, federated-entity-alias-claude-history-memory-entity-extension-claude-local-session-memory-entity-com
- Example: Extension <> Invalid network egress hostname patterns [disjoint] score=0.83
- Proposed outcome: reject
- Manual outcome: 
- Notes: 
- Review: Reject unless external context ties these labels to the same entity.
- Review: Spot-check the top-scoring pair before closing the whole group.
- Review: Verify labels are not headings, placeholders, fragments, or extraction residue.

## Sample 7: com
- Bucket: likely-reject
- Flags: has-low-specificity-labels, all-zero-overlap
- Labels: Com, Invalid network egress hostname patterns, Network, Settings
- Review IDs: federated-entity-alias-claude-history-memory-entity-com-claude-local-session-memory-entity-invalid-netw, federated-entity-alias-claude-history-memory-entity-com-claude-local-session-memory-entity-network, federated-entity-alias-claude-history-memory-entity-com-claude-local-session-memory-entity-settings
- Example: Com <> Invalid network egress hostname patterns [disjoint] score=0.83
- Proposed outcome: reject
- Manual outcome: 
- Notes: 
- Review: Reject unless external context ties these labels to the same entity.
- Review: Spot-check the top-scoring pair before closing the whole group.
- Review: Verify labels are not headings, placeholders, fragments, or extraction residue.

## Sample 8: format
- Bucket: likely-reject
- Flags: all-zero-overlap
- Labels: Artie, Artie Lange's evolution on Howard TV, Format, Staff
- Review IDs: federated-entity-alias-claude-history-memory-entity-format-claude-local-session-memory-entity-artie, federated-entity-alias-claude-history-memory-entity-format-claude-local-session-memory-entity-artie-lan, federated-entity-alias-claude-history-memory-entity-format-claude-local-session-memory-entity-staff
- Example: Format <> Artie [disjoint] score=0.86
- Proposed outcome: reject
- Manual outcome: 
- Notes: 
- Review: Reject unless external context ties these labels to the same entity.
- Review: Spot-check the top-scoring pair before closing the whole group.

## Sample 9: personal
- Bucket: likely-reject
- Flags: all-zero-overlap
- Labels: Personal, Remix of Stories in the Sky, Star, Stars
- Review IDs: federated-entity-alias-claude-history-memory-entity-personal-claude-local-session-memory-entity-remix-o, federated-entity-alias-claude-history-memory-entity-personal-claude-local-session-memory-entity-star, federated-entity-alias-claude-history-memory-entity-personal-claude-local-session-memory-entity-stars
- Example: Personal <> Remix of Stories in the Sky [disjoint] score=0.86
- Proposed outcome: reject
- Manual outcome: 
- Notes: 
- Review: Reject unless external context ties these labels to the same entity.
- Review: Spot-check the top-scoring pair before closing the whole group.

## Sample 10: tool
- Bucket: likely-reject
- Flags: all-zero-overlap
- Labels: Remix of Expansive Inquiry AI Collaboration System, Stage, Stageindex, Tool
- Review IDs: federated-entity-alias-claude-history-memory-entity-tool-claude-local-session-memory-entity-remix-of-ex, federated-entity-alias-claude-history-memory-entity-tool-claude-local-session-memory-entity-stage, federated-entity-alias-claude-history-memory-entity-tool-claude-local-session-memory-entity-stageindex
- Example: Tool <> Remix of Expansive Inquiry AI Collaboration System [disjoint] score=0.88
- Proposed outcome: reject
- Manual outcome: 
- Notes: 
- Review: Reject unless external context ties these labels to the same entity.
- Review: Spot-check the top-scoring pair before closing the whole group.

## Sample 11: involuntary
- Bucket: likely-reject
- Flags: all-zero-overlap
- Labels: Attention, Attention economy across media forms, Horror, Involuntary, Jazz
- Review IDs: federated-entity-alias-claude-history-memory-entity-involuntary-claude-local-session-memory-entity-atte, federated-entity-alias-claude-history-memory-entity-involuntary-claude-local-session-memory-entity-atte, federated-entity-alias-claude-history-memory-entity-involuntary-claude-local-session-memory-entity-horr
- Example: Involuntary <> Attention [disjoint] score=0.83
- Proposed outcome: reject
- Manual outcome: 
- Notes: 
- Review: Reject unless external context ties these labels to the same entity.
- Review: Spot-check the top-scoring pair before closing the whole group.

## Sample 12: comprehensive
- Bucket: likely-reject
- Flags: all-zero-overlap
- Labels: Annotated, Claude project manifest with annotated bibliography, Comprehensive, Risk
- Review IDs: federated-entity-alias-claude-history-memory-entity-comprehensive-claude-local-session-memory-entity-an, federated-entity-alias-claude-history-memory-entity-comprehensive-claude-local-session-memory-entity-cl, federated-entity-alias-claude-history-memory-entity-comprehensive-claude-local-session-memory-entity-ri
- Example: Comprehensive <> Annotated [disjoint] score=0.86
- Proposed outcome: reject
- Manual outcome: 
- Notes: 
- Review: Reject unless external context ties these labels to the same entity.
- Review: Spot-check the top-scoring pair before closing the whole group.
