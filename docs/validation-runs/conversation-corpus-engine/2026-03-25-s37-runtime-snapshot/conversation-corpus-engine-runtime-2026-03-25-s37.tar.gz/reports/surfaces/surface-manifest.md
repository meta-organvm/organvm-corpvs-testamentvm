# Surface Manifest

- Generated: 2026-03-21T16:25:49.439252+00:00
- Package: conversation-corpus-engine
- Version: 0.1.0
- Project root: /Users/4jp/Workspace/organvm-i-theoria/conversation-corpus-engine
- Source-drop root: /Users/4jp/Workspace/organvm-i-theoria/source-drop
- Registered corpora: 5
- Active corpora: 5
- Providers: 5

## Registry

- ai-exports-markdown-memory: status=active gate=pass freshness=stale
- brainstorm-transcript-memory: status=active gate=pass freshness=fresh
- chatgpt-history: status=active gate=pass freshness=not_applicable
- claude-history-memory: status=active gate=warn freshness=fresh
- claude-local-session-memory: status=active gate=pass freshness=fresh

## Providers

- claude: readiness=healthy-federation next=ready
- copilot: readiness=missing next=Place a supported Copilot export in /Users/4jp/Workspace/organvm-i-theoria/source-drop/copilot/inbox
- gemini: readiness=missing next=Place a supported Gemini export in /Users/4jp/Workspace/organvm-i-theoria/source-drop/gemini/inbox
- grok: readiness=missing next=Place a supported Grok export in /Users/4jp/Workspace/organvm-i-theoria/source-drop/grok/inbox
- perplexity: readiness=missing next=Place a supported Perplexity export in /Users/4jp/Workspace/organvm-i-theoria/source-drop/perplexity/inbox
