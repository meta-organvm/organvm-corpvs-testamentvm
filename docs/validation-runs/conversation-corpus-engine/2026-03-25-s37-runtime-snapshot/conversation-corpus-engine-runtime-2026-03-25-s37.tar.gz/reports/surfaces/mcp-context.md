# MCP Context

- Generated: 2026-03-21T16:25:49.581881+00:00
- Active corpora: 5
- Providers: 5
- Healthy providers: 1
- Refresh recommended: 0
- Open review items: 4272

## Provider States

- claude: healthy-federation next=ready
- gemini: missing next=Place a supported Gemini export in /Users/4jp/Workspace/organvm-i-theoria/source-drop/gemini/inbox
- grok: missing next=Place a supported Grok export in /Users/4jp/Workspace/organvm-i-theoria/source-drop/grok/inbox
- perplexity: missing next=Place a supported Perplexity export in /Users/4jp/Workspace/organvm-i-theoria/source-drop/perplexity/inbox
- copilot: missing next=Place a supported Copilot export in /Users/4jp/Workspace/organvm-i-theoria/source-drop/copilot/inbox
