# Surface Bundle

- Generated: 2026-03-21T16:25:49.583846+00:00
- Overall valid: yes
- Error count: 0
- Manifest path: /Users/4jp/Workspace/organvm-i-theoria/conversation-corpus-engine/reports/surfaces/surface-manifest.json
- Context path: /Users/4jp/Workspace/organvm-i-theoria/conversation-corpus-engine/reports/surfaces/mcp-context.json

## Validation

- Surface manifest: pass
- MCP context: pass
- Bundle envelope: pass
