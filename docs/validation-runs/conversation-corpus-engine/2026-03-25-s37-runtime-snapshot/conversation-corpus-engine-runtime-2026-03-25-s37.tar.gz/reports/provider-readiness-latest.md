# Provider Readiness

- Generated: 2026-03-21T13:59:51.649542+00:00
- Providers: 5
- Corpora present: 1
- Bootstrap-ready corpora: 0
- Manual-pass corpora: 1
- Registered active corpora: 1

## Claude

- Overall state: healthy-federation
- Selected corpus: claude-local-session-memory
- Selected root: /Users/4jp/Workspace/intake/ai-exports/claude-local-session-memory
- Adapter type: claude-local-session
- Evaluation gate: pass
- Registered: yes
- Inbox state: ready
- Next command: `ready`

### Targets

- primary: claude-local-session-memory  state=healthy-federation  registered=yes
  root: /Users/4jp/Workspace/intake/ai-exports/claude-local-session-memory
  gate: pass  freshness: fresh
- fallback: claude-history-memory  state=imported-needs-bootstrap  registered=yes
  root: /Users/4jp/Workspace/intake/ai-exports/claude-history-memory
  gate: warn  freshness: fresh

## Gemini

- Overall state: missing
- Selected corpus: gemini-history-memory
- Selected root: /Users/4jp/Workspace/intake/ai-exports/gemini-history-memory
- Adapter type: n/a
- Evaluation gate: n/a
- Registered: no
- Inbox state: empty
- Next command: `Place a supported Gemini export in /Users/4jp/Workspace/intake/ai-exports/source-drop/gemini/inbox`

### Targets

- primary: gemini-history-memory  state=missing  registered=no
  root: /Users/4jp/Workspace/intake/ai-exports/gemini-history-memory

## Grok

- Overall state: missing
- Selected corpus: grok-history-memory
- Selected root: /Users/4jp/Workspace/intake/ai-exports/grok-history-memory
- Adapter type: n/a
- Evaluation gate: n/a
- Registered: no
- Inbox state: empty
- Next command: `Place a supported Grok export in /Users/4jp/Workspace/intake/ai-exports/source-drop/grok/inbox`

### Targets

- primary: grok-history-memory  state=missing  registered=no
  root: /Users/4jp/Workspace/intake/ai-exports/grok-history-memory

## Perplexity

- Overall state: missing
- Selected corpus: perplexity-history-memory
- Selected root: /Users/4jp/Workspace/intake/ai-exports/perplexity-history-memory
- Adapter type: n/a
- Evaluation gate: n/a
- Registered: no
- Inbox state: empty
- Next command: `Place a supported Perplexity export in /Users/4jp/Workspace/intake/ai-exports/source-drop/perplexity/inbox`

### Targets

- primary: perplexity-history-memory  state=missing  registered=no
  root: /Users/4jp/Workspace/intake/ai-exports/perplexity-history-memory

## Copilot

- Overall state: missing
- Selected corpus: copilot-history-memory
- Selected root: /Users/4jp/Workspace/intake/ai-exports/copilot-history-memory
- Adapter type: n/a
- Evaluation gate: n/a
- Registered: no
- Inbox state: empty
- Next command: `Place a supported Copilot export in /Users/4jp/Workspace/intake/ai-exports/source-drop/copilot/inbox`
- Note: Current Copilot ingestion targets exported conversation bundles, not IDE extension traces.

### Targets

- primary: copilot-history-memory  state=missing  registered=no
  root: /Users/4jp/Workspace/intake/ai-exports/copilot-history-memory
