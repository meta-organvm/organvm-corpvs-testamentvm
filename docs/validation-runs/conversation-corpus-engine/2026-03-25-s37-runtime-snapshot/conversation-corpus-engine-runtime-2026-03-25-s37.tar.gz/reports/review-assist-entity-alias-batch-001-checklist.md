# Entity-alias review checklist: entity-alias-batch-001

- Items: 23
- Groups: 6
- Scope: 400 filtered / 406 open
- Selected batch: entity-alias-batch-001 (1/17)

## 1. chapters
- Bucket: likely-reject
- Flags: has-low-specificity-labels, all-zero-overlap
- Labels: Bharata-Muni's narrative principles as algorithms, Chapters, Missing, Primary, Remaining, Supplement
- Review IDs: federated-entity-alias-claude-history-memory-entity-chapters-claude-local-session-memory-entity-bharata, federated-entity-alias-claude-history-memory-entity-chapters-claude-local-session-memory-entity-missing, federated-entity-alias-claude-history-memory-entity-chapters-claude-local-session-memory-entity-primary
- Example: Chapters <> Bharata-Muni's narrative principles as algorithms [disjoint] score=0.83
- Review: Reject unless external context ties these labels to the same entity.
- Review: Spot-check the top-scoring pair before closing the whole group.
- Review: Verify labels are not headings, placeholders, fragments, or extraction residue.

## 2. extension
- Bucket: likely-reject
- Flags: has-low-specificity-labels, all-zero-overlap
- Labels: Com, Extension, Invalid network egress hostname patterns, Network, Settings
- Review IDs: federated-entity-alias-claude-history-memory-entity-extension-claude-local-session-memory-entity-invali, federated-entity-alias-claude-history-memory-entity-extension-claude-local-session-memory-entity-networ, federated-entity-alias-claude-history-memory-entity-extension-claude-local-session-memory-entity-com
- Example: Extension <> Invalid network egress hostname patterns [disjoint] score=0.83
- Review: Reject unless external context ties these labels to the same entity.
- Review: Spot-check the top-scoring pair before closing the whole group.
- Review: Verify labels are not headings, placeholders, fragments, or extraction residue.

## 3. involuntary
- Bucket: likely-reject
- Flags: all-zero-overlap
- Labels: Attention, Attention economy across media forms, Horror, Involuntary, Jazz
- Review IDs: federated-entity-alias-claude-history-memory-entity-involuntary-claude-local-session-memory-entity-atte, federated-entity-alias-claude-history-memory-entity-involuntary-claude-local-session-memory-entity-atte, federated-entity-alias-claude-history-memory-entity-involuntary-claude-local-session-memory-entity-horr
- Example: Involuntary <> Attention [disjoint] score=0.83
- Review: Reject unless external context ties these labels to the same entity.
- Review: Spot-check the top-scoring pair before closing the whole group.

## 4. von
- Bucket: likely-reject
- Flags: has-low-specificity-labels, all-zero-overlap
- Labels: Both, Deleuze, Philosophical frameworks for reciprocal performance, Von, Whitehead
- Review IDs: federated-entity-alias-claude-history-memory-entity-von-claude-local-session-memory-entity-philosophica, federated-entity-alias-claude-history-memory-entity-von-claude-local-session-memory-entity-both, federated-entity-alias-claude-history-memory-entity-von-claude-local-session-memory-entity-deleuze
- Example: Von <> Philosophical frameworks for reciprocal performance [disjoint] score=0.83
- Review: Reject unless external context ties these labels to the same entity.
- Review: Spot-check the top-scoring pair before closing the whole group.
- Review: Verify labels are not headings, placeholders, fragments, or extraction residue.

## 5. 000
- Bucket: likely-reject
- Flags: has-low-specificity-labels, all-zero-overlap
- Labels: 000, Income, Medicaid, Research report from document inquiry
- Review IDs: federated-entity-alias-claude-history-memory-entity-000-claude-local-session-memory-entity-research-rep, federated-entity-alias-claude-history-memory-entity-000-claude-local-session-memory-entity-income, federated-entity-alias-claude-history-memory-entity-000-claude-local-session-memory-entity-medicaid
- Example: 000 <> Research report from document inquiry [disjoint] score=0.83
- Review: Reject unless external context ties these labels to the same entity.
- Review: Spot-check the top-scoring pair before closing the whole group.
- Review: Verify labels are not headings, placeholders, fragments, or extraction residue.

## 6. checklist
- Bucket: needs-context
- Flags: has-low-specificity-labels, has-high-score-disjoint-pairs, all-zero-overlap
- Labels: Checklist, Ctr, Retention, Thumbnail
- Review IDs: federated-entity-alias-claude-history-memory-entity-checklist-claude-local-session-memory-entity-retent, federated-entity-alias-claude-history-memory-entity-checklist-claude-local-session-memory-entity-ctr, federated-entity-alias-claude-history-memory-entity-checklist-claude-local-session-memory-entity-thumbn
- Example: Checklist <> Retention [disjoint] score=1.00
- Review: Inspect the highest-scoring pair before rejecting; upstream signal is stronger than lexical overlap.
- Review: Reject only if the pair still reads like neighboring topics rather than the same entity.
- Review: Verify labels are not headings, placeholders, fragments, or extraction residue.
