Entity-alias review sample proposal
Source: /Users/4jp/Workspace/organvm-i-theoria/conversation-corpus-engine/reports/review-assist-sample-2026-03-25-113846.md
Samples: 8
Packet: scope=400 filtered / 406 open  buckets=needs-context  sampled_groups=8
Assistant outcomes: needs-context=8
Assistant confidence: medium=8

- checklist  bucket=needs-context  assistant=needs-context  confidence=medium
  rationale: Group bucket explicitly requires contextual inspection before rejection.
- coast  bucket=needs-context  assistant=needs-context  confidence=medium
  rationale: Group bucket explicitly requires contextual inspection before rejection.
- alerts  bucket=needs-context  assistant=needs-context  confidence=medium
  rationale: Group bucket explicitly requires contextual inspection before rejection.
- care  bucket=needs-context  assistant=needs-context  confidence=medium
  rationale: Group bucket explicitly requires contextual inspection before rejection.
- feature  bucket=needs-context  assistant=needs-context  confidence=medium
  rationale: Group bucket explicitly requires contextual inspection before rejection.
- manga  bucket=needs-context  assistant=needs-context  confidence=medium
  rationale: Group bucket explicitly requires contextual inspection before rejection.
- plato  bucket=needs-context  assistant=needs-context  confidence=medium
  rationale: Group bucket explicitly requires contextual inspection before rejection.
- string  bucket=needs-context  assistant=needs-context  confidence=medium
  rationale: Group bucket explicitly requires contextual inspection before rejection.
