Entity-alias review packet hydration
Source: /Users/4jp/Workspace/organvm-i-theoria/conversation-corpus-engine/reports/review-assist-sample-2026-03-25-123012-122496-likely_front.md
Packet ID: 2026-03-25-123012-122496-likely_front
Valid: False  Errors: 2  Warnings: 0
Samples: 12  Adjudicated: 0  Pending: 12
Errors:
- sample 2: duplicate-review-id  Review ID federated-entity-alias-claude-history-memory-entity-collision-claude-local-session-memory-entity-storyl is duplicated in samples 2 and 2.
- sample 11: duplicate-review-id  Review ID federated-entity-alias-claude-history-memory-entity-involuntary-claude-local-session-memory-entity-atte is duplicated in samples 11 and 11.

- sample 1  anchor=chapters  bucket=likely-reject  manual=pending
  review_ids: federated-entity-alias-claude-history-memory-entity-chapters-claude-local-session-memory-entity-bharata, federated-entity-alias-claude-history-memory-entity-chapters-claude-local-session-memory-entity-missing, federated-entity-alias-claude-history-memory-entity-chapters-claude-local-session-memory-entity-primary
- sample 2  anchor=collision  bucket=likely-reject  manual=pending
  review_ids: federated-entity-alias-claude-history-memory-entity-collision-claude-local-session-memory-entity-david, federated-entity-alias-claude-history-memory-entity-collision-claude-local-session-memory-entity-storyl, federated-entity-alias-claude-history-memory-entity-collision-claude-local-session-memory-entity-storyl
- sample 3  anchor=family  bucket=likely-reject  manual=pending
  review_ids: federated-entity-alias-claude-history-memory-entity-family-claude-local-session-memory-entity-script-an, federated-entity-alias-claude-history-memory-entity-family-claude-local-session-memory-entity-fre, federated-entity-alias-claude-history-memory-entity-family-claude-local-session-memory-entity-rok
- sample 4  anchor=parallel  bucket=likely-reject  manual=pending
  review_ids: federated-entity-alias-claude-history-memory-entity-parallel-claude-local-session-memory-entity-transfo, federated-entity-alias-claude-history-memory-entity-parallel-claude-local-session-memory-entity-touring, federated-entity-alias-claude-history-memory-entity-parallel-claude-local-session-memory-entity-years
- sample 5  anchor=thumbnail  bucket=likely-reject  manual=pending
  review_ids: federated-entity-alias-claude-history-memory-entity-thumbnail-claude-local-session-memory-entity-hokage, federated-entity-alias-claude-history-memory-entity-thumbnail-claude-local-session-memory-entity-retent, federated-entity-alias-claude-history-memory-entity-thumbnail-claude-local-session-memory-entity-ctr
- sample 6  anchor=extension  bucket=likely-reject  manual=pending
  review_ids: federated-entity-alias-claude-history-memory-entity-extension-claude-local-session-memory-entity-invali, federated-entity-alias-claude-history-memory-entity-extension-claude-local-session-memory-entity-networ, federated-entity-alias-claude-history-memory-entity-extension-claude-local-session-memory-entity-com
- sample 7  anchor=com  bucket=likely-reject  manual=pending
  review_ids: federated-entity-alias-claude-history-memory-entity-com-claude-local-session-memory-entity-invalid-netw, federated-entity-alias-claude-history-memory-entity-com-claude-local-session-memory-entity-network, federated-entity-alias-claude-history-memory-entity-com-claude-local-session-memory-entity-settings
- sample 8  anchor=format  bucket=likely-reject  manual=pending
  review_ids: federated-entity-alias-claude-history-memory-entity-format-claude-local-session-memory-entity-artie, federated-entity-alias-claude-history-memory-entity-format-claude-local-session-memory-entity-artie-lan, federated-entity-alias-claude-history-memory-entity-format-claude-local-session-memory-entity-staff
- sample 9  anchor=personal  bucket=likely-reject  manual=pending
  review_ids: federated-entity-alias-claude-history-memory-entity-personal-claude-local-session-memory-entity-remix-o, federated-entity-alias-claude-history-memory-entity-personal-claude-local-session-memory-entity-star, federated-entity-alias-claude-history-memory-entity-personal-claude-local-session-memory-entity-stars
- sample 10  anchor=tool  bucket=likely-reject  manual=pending
  review_ids: federated-entity-alias-claude-history-memory-entity-tool-claude-local-session-memory-entity-remix-of-ex, federated-entity-alias-claude-history-memory-entity-tool-claude-local-session-memory-entity-stage, federated-entity-alias-claude-history-memory-entity-tool-claude-local-session-memory-entity-stageindex
- sample 11  anchor=involuntary  bucket=likely-reject  manual=pending
  review_ids: federated-entity-alias-claude-history-memory-entity-involuntary-claude-local-session-memory-entity-atte, federated-entity-alias-claude-history-memory-entity-involuntary-claude-local-session-memory-entity-atte, federated-entity-alias-claude-history-memory-entity-involuntary-claude-local-session-memory-entity-horr
- sample 12  anchor=comprehensive  bucket=likely-reject  manual=pending
  review_ids: federated-entity-alias-claude-history-memory-entity-comprehensive-claude-local-session-memory-entity-an, federated-entity-alias-claude-history-memory-entity-comprehensive-claude-local-session-memory-entity-cl, federated-entity-alias-claude-history-memory-entity-comprehensive-claude-local-session-memory-entity-ri
