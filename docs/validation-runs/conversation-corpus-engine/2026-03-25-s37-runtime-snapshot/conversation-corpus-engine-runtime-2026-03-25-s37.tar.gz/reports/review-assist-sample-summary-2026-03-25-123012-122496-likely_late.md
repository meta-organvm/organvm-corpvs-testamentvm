Entity-alias review sample summary
Source: campaign:likely_late:sample
Samples: 12  Adjudicated: 0  Decisive: 0
Reject precision: n/a
Confirmed rejects: 0  False positives: 0  Needs context: 0  Pending: 12
Packet: scope=400 filtered / 406 open  buckets=likely-reject  sampled_groups=12
Buckets: likely-reject=12

- across  bucket=likely-reject  proposed=reject  manual=pending
- csv  bucket=likely-reject  proposed=reject  manual=pending
- helix  bucket=likely-reject  proposed=reject  manual=pending
- minimal  bucket=likely-reject  proposed=reject  manual=pending
- philosophical  bucket=likely-reject  proposed=reject  manual=pending
- added  bucket=likely-reject  proposed=reject  manual=pending
- cube  bucket=likely-reject  proposed=reject  manual=pending
- home  bucket=likely-reject  proposed=reject  manual=pending
- mobile  bucket=likely-reject  proposed=reject  manual=pending
- pieces  bucket=likely-reject  proposed=reject  manual=pending
... 2 more samples
