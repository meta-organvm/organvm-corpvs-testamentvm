Entity-alias review campaign index
Project: /Users/4jp/Workspace/organvm-i-theoria/conversation-corpus-engine
Campaigns: 1  Packets: 11
Samples: 120  Adjudicated: 0  Pending: 120
Packet status: pending=11
Campaign status: pending=1
Scenarios: likely_front=1, likely_late=1, likely_mid=1, needs_context=1

Campaigns:
- 2026-03-25-123012-122496  status=pending  scenarios=4  sampled_groups=44  adjudicated=0  reject_precision=n/a

Packets:
- 2026-03-25-105452  status=pending  samples=12  adjudicated=0  scenario=legacy
  sample: /Users/4jp/Workspace/organvm-i-theoria/conversation-corpus-engine/reports/review-assist-sample-2026-03-25-105452.md
- 2026-03-25-113845  status=pending  samples=12  adjudicated=0  scenario=legacy
  sample: /Users/4jp/Workspace/organvm-i-theoria/conversation-corpus-engine/reports/review-assist-sample-2026-03-25-113845.md
- 2026-03-25-113846  status=pending  samples=8  adjudicated=0  scenario=legacy
  sample: /Users/4jp/Workspace/organvm-i-theoria/conversation-corpus-engine/reports/review-assist-sample-2026-03-25-113846.md
- 2026-03-25-113955-087698  status=pending  samples=12  adjudicated=0  scenario=legacy
  sample: /Users/4jp/Workspace/organvm-i-theoria/conversation-corpus-engine/reports/review-assist-sample-2026-03-25-113955-087698.md
- 2026-03-25-113955-292340  status=pending  samples=12  adjudicated=0  scenario=legacy
  sample: /Users/4jp/Workspace/organvm-i-theoria/conversation-corpus-engine/reports/review-assist-sample-2026-03-25-113955-292340.md
- 2026-03-25-113955-509034  status=pending  samples=12  adjudicated=0  scenario=legacy
  sample: /Users/4jp/Workspace/organvm-i-theoria/conversation-corpus-engine/reports/review-assist-sample-2026-03-25-113955-509034.md
- 2026-03-25-113955-712523  status=pending  samples=8  adjudicated=0  scenario=legacy
  sample: /Users/4jp/Workspace/organvm-i-theoria/conversation-corpus-engine/reports/review-assist-sample-2026-03-25-113955-712523.md
- 2026-03-25-123012-122496-likely_front  status=pending  samples=12  adjudicated=0  scenario=likely_front
  campaigns: 2026-03-25-123012-122496
  sample: /Users/4jp/Workspace/organvm-i-theoria/conversation-corpus-engine/reports/review-assist-sample-2026-03-25-123012-122496-likely_front.md
- 2026-03-25-123012-122496-likely_late  status=pending  samples=12  adjudicated=0  scenario=likely_late
  campaigns: 2026-03-25-123012-122496
  sample: /Users/4jp/Workspace/organvm-i-theoria/conversation-corpus-engine/reports/review-assist-sample-2026-03-25-123012-122496-likely_late.md
- 2026-03-25-123012-122496-likely_mid  status=pending  samples=12  adjudicated=0  scenario=likely_mid
  campaigns: 2026-03-25-123012-122496
  sample: /Users/4jp/Workspace/organvm-i-theoria/conversation-corpus-engine/reports/review-assist-sample-2026-03-25-123012-122496-likely_mid.md
- 2026-03-25-123012-122496-needs_context  status=pending  samples=8  adjudicated=0  scenario=needs_context
  campaigns: 2026-03-25-123012-122496
  sample: /Users/4jp/Workspace/organvm-i-theoria/conversation-corpus-engine/reports/review-assist-sample-2026-03-25-123012-122496-needs_context.md
