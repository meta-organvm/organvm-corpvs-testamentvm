Entity-alias review sample proposal
Source: campaign:likely_front:sample
Samples: 12
Packet: scope=400 filtered / 406 open  buckets=likely-reject  sampled_groups=12
Assistant outcomes: reject=12
Assistant confidence: high=12

- chapters  bucket=likely-reject  assistant=reject  confidence=high
  rationale: Group is already classified as likely-reject.
  rationale: Lexical overlap is absent across the sampled pairs.
  rationale: At least one label looks like a heading, fragment, placeholder, or extraction residue.
- collision  bucket=likely-reject  assistant=reject  confidence=high
  rationale: Group is already classified as likely-reject.
  rationale: Lexical overlap is absent across the sampled pairs.
- family  bucket=likely-reject  assistant=reject  confidence=high
  rationale: Group is already classified as likely-reject.
  rationale: Lexical overlap is absent across the sampled pairs.
  rationale: At least one label looks like a heading, fragment, placeholder, or extraction residue.
- parallel  bucket=likely-reject  assistant=reject  confidence=high
  rationale: Group is already classified as likely-reject.
  rationale: Lexical overlap is absent across the sampled pairs.
- thumbnail  bucket=likely-reject  assistant=reject  confidence=high
  rationale: Group is already classified as likely-reject.
  rationale: Lexical overlap is absent across the sampled pairs.
  rationale: At least one label looks like a heading, fragment, placeholder, or extraction residue.
- extension  bucket=likely-reject  assistant=reject  confidence=high
  rationale: Group is already classified as likely-reject.
  rationale: Lexical overlap is absent across the sampled pairs.
  rationale: At least one label looks like a heading, fragment, placeholder, or extraction residue.
- com  bucket=likely-reject  assistant=reject  confidence=high
  rationale: Group is already classified as likely-reject.
  rationale: Lexical overlap is absent across the sampled pairs.
  rationale: At least one label looks like a heading, fragment, placeholder, or extraction residue.
- format  bucket=likely-reject  assistant=reject  confidence=high
  rationale: Group is already classified as likely-reject.
  rationale: Lexical overlap is absent across the sampled pairs.
- personal  bucket=likely-reject  assistant=reject  confidence=high
  rationale: Group is already classified as likely-reject.
  rationale: Lexical overlap is absent across the sampled pairs.
- tool  bucket=likely-reject  assistant=reject  confidence=high
  rationale: Group is already classified as likely-reject.
  rationale: Lexical overlap is absent across the sampled pairs.
- involuntary  bucket=likely-reject  assistant=reject  confidence=high
  rationale: Group is already classified as likely-reject.
  rationale: Lexical overlap is absent across the sampled pairs.
- comprehensive  bucket=likely-reject  assistant=reject  confidence=high
  rationale: Group is already classified as likely-reject.
  rationale: Lexical overlap is absent across the sampled pairs.
