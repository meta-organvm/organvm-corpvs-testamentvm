Entity-alias review completion scoreboard
Project: /Users/4jp/Workspace/organvm-i-theoria/conversation-corpus-engine
Current adjudicated: 0  Remaining to threshold: 20
Current reject precision: n/a
Buckets: precision-ready=5, campaign-backlog=4, legacy-backfill=2

- 2026-03-25-113955-292340  bucket=precision-ready  score=165  pending=12  valid=True
  scenario=legacy  compare=True  proposal=True  threshold_gap_after=8
- 2026-03-25-113955-509034  bucket=precision-ready  score=165  pending=12  valid=True
  scenario=legacy  compare=True  proposal=True  threshold_gap_after=8
- 2026-03-25-123012-122496-likely_late  bucket=campaign-backlog  score=140  pending=12  valid=True
  scenario=likely_late  compare=False  proposal=False  threshold_gap_after=8
- 2026-03-25-123012-122496-likely_mid  bucket=campaign-backlog  score=140  pending=12  valid=True
  scenario=likely_mid  compare=False  proposal=False  threshold_gap_after=8
- 2026-03-25-113846  bucket=precision-ready  score=125  pending=8  valid=True
  scenario=legacy  compare=True  proposal=True  threshold_gap_after=12
- 2026-03-25-113955-712523  bucket=precision-ready  score=125  pending=8  valid=True
  scenario=legacy  compare=True  proposal=True  threshold_gap_after=12
- 2026-03-25-113955-087698  bucket=precision-ready  score=115  pending=12  valid=False
  scenario=legacy  compare=True  proposal=True  threshold_gap_after=8
- 2026-03-25-123012-122496-needs_context  bucket=campaign-backlog  score=100  pending=8  valid=True
  scenario=needs_context  compare=False  proposal=False  threshold_gap_after=12
- 2026-03-25-123012-122496-likely_front  bucket=campaign-backlog  score=90  pending=12  valid=False
  scenario=likely_front  compare=False  proposal=False  threshold_gap_after=8
- 2026-03-25-105452  bucket=legacy-backfill  score=70  pending=12  valid=False
  scenario=legacy  compare=False  proposal=False  threshold_gap_after=8
- 2026-03-25-113845  bucket=legacy-backfill  score=70  pending=12  valid=False
  scenario=legacy  compare=False  proposal=False  threshold_gap_after=8
