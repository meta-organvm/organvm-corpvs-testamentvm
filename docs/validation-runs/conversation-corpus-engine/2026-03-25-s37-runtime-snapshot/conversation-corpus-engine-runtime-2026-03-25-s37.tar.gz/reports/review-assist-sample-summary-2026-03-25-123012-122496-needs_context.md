Entity-alias review sample summary
Source: campaign:needs_context:sample
Samples: 8  Adjudicated: 0  Decisive: 0
Reject precision: n/a
Confirmed rejects: 0  False positives: 0  Needs context: 0  Pending: 8
Packet: scope=400 filtered / 406 open  buckets=needs-context  sampled_groups=8
Buckets: needs-context=8

- checklist  bucket=needs-context  proposed=reject  manual=pending
- coast  bucket=needs-context  proposed=reject  manual=pending
- alerts  bucket=needs-context  proposed=reject  manual=pending
- care  bucket=needs-context  proposed=reject  manual=pending
- feature  bucket=needs-context  proposed=reject  manual=pending
- manga  bucket=needs-context  proposed=reject  manual=pending
- plato  bucket=needs-context  proposed=reject  manual=pending
- string  bucket=needs-context  proposed=reject  manual=pending
