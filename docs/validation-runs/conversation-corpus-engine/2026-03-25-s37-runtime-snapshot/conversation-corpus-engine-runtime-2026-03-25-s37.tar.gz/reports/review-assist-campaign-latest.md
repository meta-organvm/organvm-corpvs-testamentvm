Entity-alias review campaign
Project: /Users/4jp/Workspace/organvm-i-theoria/conversation-corpus-engine
Scenarios: 4  Batch size: 25
Sampled groups: 44  Sampled items: 94  Adjudicated: 0
Proposal reject precision: n/a
Assistant outcomes: reject=36, needs-context=8
Assistant confidence: high=36, medium=8

- likely_front: Front-window likely-reject sample
  sample: groups=12 items=40 candidate_groups=36 candidate_batches=5 batch_offset=0
  assistant: reject=12
  compare: adjudicated=0 agreement=0 disagreement=0 reject_precision=n/a
  sample_artifact: /Users/4jp/Workspace/organvm-i-theoria/conversation-corpus-engine/reports/review-assist-sample-2026-03-25-123012-122496-likely_front.md
  proposal_artifact: /Users/4jp/Workspace/organvm-i-theoria/conversation-corpus-engine/reports/review-assist-sample-proposal-2026-03-25-123012-122496-likely_front.md
  compare_artifact: /Users/4jp/Workspace/organvm-i-theoria/conversation-corpus-engine/reports/review-assist-sample-compare-2026-03-25-123012-122496-likely_front.md

- likely_mid: Mid-window likely-reject sample
  sample: groups=12 items=24 candidate_groups=50 candidate_batches=5 batch_offset=5
  assistant: reject=12
  compare: adjudicated=0 agreement=0 disagreement=0 reject_precision=n/a
  sample_artifact: /Users/4jp/Workspace/organvm-i-theoria/conversation-corpus-engine/reports/review-assist-sample-2026-03-25-123012-122496-likely_mid.md
  proposal_artifact: /Users/4jp/Workspace/organvm-i-theoria/conversation-corpus-engine/reports/review-assist-sample-proposal-2026-03-25-123012-122496-likely_mid.md
  compare_artifact: /Users/4jp/Workspace/organvm-i-theoria/conversation-corpus-engine/reports/review-assist-sample-compare-2026-03-25-123012-122496-likely_mid.md

- likely_late: Late-window likely-reject sample
  sample: groups=12 items=12 candidate_groups=114 candidate_batches=5 batch_offset=10
  assistant: reject=12
  compare: adjudicated=0 agreement=0 disagreement=0 reject_precision=n/a
  sample_artifact: /Users/4jp/Workspace/organvm-i-theoria/conversation-corpus-engine/reports/review-assist-sample-2026-03-25-123012-122496-likely_late.md
  proposal_artifact: /Users/4jp/Workspace/organvm-i-theoria/conversation-corpus-engine/reports/review-assist-sample-proposal-2026-03-25-123012-122496-likely_late.md
  compare_artifact: /Users/4jp/Workspace/organvm-i-theoria/conversation-corpus-engine/reports/review-assist-sample-compare-2026-03-25-123012-122496-likely_late.md

- needs_context: Front-window needs-context sample
  sample: groups=8 items=18 candidate_groups=22 candidate_batches=10 batch_offset=0
  assistant: needs-context=8
  compare: adjudicated=0 agreement=0 disagreement=0 reject_precision=n/a
  sample_artifact: /Users/4jp/Workspace/organvm-i-theoria/conversation-corpus-engine/reports/review-assist-sample-2026-03-25-123012-122496-needs_context.md
  proposal_artifact: /Users/4jp/Workspace/organvm-i-theoria/conversation-corpus-engine/reports/review-assist-sample-proposal-2026-03-25-123012-122496-needs_context.md
  compare_artifact: /Users/4jp/Workspace/organvm-i-theoria/conversation-corpus-engine/reports/review-assist-sample-compare-2026-03-25-123012-122496-needs_context.md
