Entity-alias review sample proposal
Source: campaign:likely_mid:sample
Samples: 12
Packet: scope=400 filtered / 406 open  buckets=likely-reject  sampled_groups=12
Assistant outcomes: reject=12
Assistant confidence: high=12

- book  bucket=likely-reject  assistant=reject  confidence=high
  rationale: Group is already classified as likely-reject.
  rationale: Lexical overlap is absent across the sampled pairs.
- entity  bucket=likely-reject  assistant=reject  confidence=high
  rationale: Group is already classified as likely-reject.
  rationale: Lexical overlap is absent across the sampled pairs.
- house  bucket=likely-reject  assistant=reject  confidence=high
  rationale: Group is already classified as likely-reject.
  rationale: Lexical overlap is absent across the sampled pairs.
- page  bucket=likely-reject  assistant=reject  confidence=high
  rationale: Group is already classified as likely-reject.
  rationale: Lexical overlap is absent across the sampled pairs.
- storyline  bucket=likely-reject  assistant=reject  confidence=high
  rationale: Group is already classified as likely-reject.
  rationale: Lexical overlap is absent across the sampled pairs.
- classical  bucket=likely-reject  assistant=reject  confidence=high
  rationale: Group is already classified as likely-reject.
  rationale: Lexical overlap is absent across the sampled pairs.
- everything  bucket=likely-reject  assistant=reject  confidence=high
  rationale: Group is already classified as likely-reject.
  rationale: Lexical overlap is absent across the sampled pairs.
- ino  bucket=likely-reject  assistant=reject  confidence=high
  rationale: Group is already classified as likely-reject.
  rationale: Lexical overlap is absent across the sampled pairs.
  rationale: At least one label looks like a heading, fragment, placeholder, or extraction residue.
- pathways  bucket=likely-reject  assistant=reject  confidence=high
  rationale: Group is already classified as likely-reject.
  rationale: Lexical overlap is absent across the sampled pairs.
  rationale: At least one label looks like a heading, fragment, placeholder, or extraction residue.
- storylines  bucket=likely-reject  assistant=reject  confidence=high
  rationale: Group is already classified as likely-reject.
  rationale: Lexical overlap is absent across the sampled pairs.
- commander  bucket=likely-reject  assistant=reject  confidence=high
  rationale: Group is already classified as likely-reject.
  rationale: Lexical overlap is absent across the sampled pairs.
- f32  bucket=likely-reject  assistant=reject  confidence=high
  rationale: Group is already classified as likely-reject.
  rationale: Lexical overlap is absent across the sampled pairs.
  rationale: At least one label looks like a heading, fragment, placeholder, or extraction residue.
