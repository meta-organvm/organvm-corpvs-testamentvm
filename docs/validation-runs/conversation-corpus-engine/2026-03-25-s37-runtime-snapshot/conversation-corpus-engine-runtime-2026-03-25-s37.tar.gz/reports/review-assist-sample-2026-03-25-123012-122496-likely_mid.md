# Entity-alias review sample

- Items: 24
- Groups: 12
- Scope: 400 filtered / 406 open
- Candidate groups: 50
- Candidate batches: 5
- Sampled groups: 12
- Batch offset: 5
- Buckets: likely-reject

## Sample 1: book
- Bucket: likely-reject
- Flags: all-zero-overlap
- Labels: Absolute, Book, Remix of SVG Movie Theater Experience
- Review IDs: federated-entity-alias-claude-history-memory-entity-book-claude-local-session-memory-entity-remix-of-sv, federated-entity-alias-claude-history-memory-entity-book-claude-local-session-memory-entity-absolute
- Example: Book <> Remix of SVG Movie Theater Experience [disjoint] score=0.86
- Proposed outcome: reject
- Manual outcome: 
- Notes: 
- Review: Reject unless external context ties these labels to the same entity.
- Review: Spot-check the top-scoring pair before closing the whole group.

## Sample 2: entity
- Bucket: likely-reject
- Flags: all-zero-overlap
- Labels: Digital sorting hat protocol design, Entity, House
- Review IDs: federated-entity-alias-claude-history-memory-entity-entity-claude-local-session-memory-entity-digital-s, federated-entity-alias-claude-history-memory-entity-entity-claude-local-session-memory-entity-house
- Example: Entity <> Digital sorting hat protocol design [disjoint] score=0.83
- Proposed outcome: reject
- Manual outcome: 
- Notes: 
- Review: Reject unless external context ties these labels to the same entity.
- Review: Spot-check the top-scoring pair before closing the whole group.

## Sample 3: house
- Bucket: likely-reject
- Flags: all-zero-overlap
- Labels: Digital sorting hat protocol design, Entity, House
- Review IDs: federated-entity-alias-claude-history-memory-entity-house-claude-local-session-memory-entity-digital-so, federated-entity-alias-claude-history-memory-entity-house-claude-local-session-memory-entity-entity
- Example: House <> Digital sorting hat protocol design [disjoint] score=0.83
- Proposed outcome: reject
- Manual outcome: 
- Notes: 
- Review: Reject unless external context ties these labels to the same entity.
- Review: Spot-check the top-scoring pair before closing the whole group.

## Sample 4: page
- Bucket: likely-reject
- Flags: all-zero-overlap
- Labels: Absolute, Page, Remix of SVG Movie Theater Experience
- Review IDs: federated-entity-alias-claude-history-memory-entity-page-claude-local-session-memory-entity-remix-of-sv, federated-entity-alias-claude-history-memory-entity-page-claude-local-session-memory-entity-absolute
- Example: Page <> Remix of SVG Movie Theater Experience [disjoint] score=0.86
- Proposed outcome: reject
- Manual outcome: 
- Notes: 
- Review: Reject unless external context ties these labels to the same entity.
- Review: Spot-check the top-scoring pair before closing the whole group.

## Sample 5: storyline
- Bucket: likely-reject
- Flags: all-zero-overlap
- Labels: Collision, David's comedic rules as narratological algorithms, Storyline
- Review IDs: federated-entity-alias-claude-history-memory-entity-storyline-claude-local-session-memory-entity-david, federated-entity-alias-claude-history-memory-entity-storyline-claude-local-session-memory-entity-collis
- Example: Storyline <> David's comedic rules as narratological algorithms [disjoint] score=0.86
- Proposed outcome: reject
- Manual outcome: 
- Notes: 
- Review: Reject unless external context ties these labels to the same entity.
- Review: Spot-check the top-scoring pair before closing the whole group.

## Sample 6: classical
- Bucket: likely-reject
- Flags: all-zero-overlap
- Labels: Absolute, Classical, Remix of SVG Movie Theater Experience
- Review IDs: federated-entity-alias-claude-history-memory-entity-classical-claude-local-session-memory-entity-remix, federated-entity-alias-claude-history-memory-entity-classical-claude-local-session-memory-entity-absolu
- Example: Classical <> Remix of SVG Movie Theater Experience [disjoint] score=0.86
- Proposed outcome: reject
- Manual outcome: 
- Notes: 
- Review: Reject unless external context ties these labels to the same entity.
- Review: Spot-check the top-scoring pair before closing the whole group.

## Sample 7: everything
- Bucket: likely-reject
- Flags: all-zero-overlap
- Labels: Everything, Theory, Universal interconnection through vibration and belief
- Review IDs: federated-entity-alias-claude-history-memory-entity-everything-claude-local-session-memory-entity-unive, federated-entity-alias-claude-history-memory-entity-everything-claude-local-session-memory-entity-theor
- Example: Everything <> Universal interconnection through vibration and belief [disjoint] score=0.86
- Proposed outcome: reject
- Manual outcome: 
- Notes: 
- Review: Reject unless external context ties these labels to the same entity.
- Review: Spot-check the top-scoring pair before closing the whole group.

## Sample 8: ino
- Bucket: likely-reject
- Flags: has-low-specificity-labels, all-zero-overlap
- Labels: Athamas, Family trauma and mythological adaptation, Ino
- Review IDs: federated-entity-alias-claude-history-memory-entity-ino-claude-local-session-memory-entity-family-traum, federated-entity-alias-claude-history-memory-entity-ino-claude-local-session-memory-entity-athamas
- Example: Ino <> Family trauma and mythological adaptation [disjoint] score=0.83
- Proposed outcome: reject
- Manual outcome: 
- Notes: 
- Review: Reject unless external context ties these labels to the same entity.
- Review: Spot-check the top-scoring pair before closing the whole group.
- Review: Verify labels are not headings, placeholders, fragments, or extraction residue.

## Sample 9: pathways
- Bucket: likely-reject
- Flags: has-low-specificity-labels, all-zero-overlap
- Labels: NYC benefits and housing resources guide, Nyc, Pathways
- Review IDs: federated-entity-alias-claude-history-memory-entity-pathways-claude-local-session-memory-entity-nyc-ben, federated-entity-alias-claude-history-memory-entity-pathways-claude-local-session-memory-entity-nyc
- Example: Pathways <> NYC benefits and housing resources guide [disjoint] score=0.86
- Proposed outcome: reject
- Manual outcome: 
- Notes: 
- Review: Reject unless external context ties these labels to the same entity.
- Review: Spot-check the top-scoring pair before closing the whole group.
- Review: Verify labels are not headings, placeholders, fragments, or extraction residue.

## Sample 10: storylines
- Bucket: likely-reject
- Flags: all-zero-overlap
- Labels: Collision, David's comedic rules as narratological algorithms, Storylines
- Review IDs: federated-entity-alias-claude-history-memory-entity-storylines-claude-local-session-memory-entity-david, federated-entity-alias-claude-history-memory-entity-storylines-claude-local-session-memory-entity-colli
- Example: Storylines <> David's comedic rules as narratological algorithms [disjoint] score=0.86
- Proposed outcome: reject
- Manual outcome: 
- Notes: 
- Review: Reject unless external context ties these labels to the same entity.
- Review: Spot-check the top-scoring pair before closing the whole group.

## Sample 11: commander
- Bucket: likely-reject
- Flags: all-zero-overlap
- Labels: Commander, Development environment setup, Environment
- Review IDs: federated-entity-alias-claude-history-memory-entity-commander-claude-local-session-memory-entity-develo, federated-entity-alias-claude-history-memory-entity-commander-claude-local-session-memory-entity-enviro
- Example: Commander <> Development environment setup [disjoint] score=0.75
- Proposed outcome: reject
- Manual outcome: 
- Notes: 
- Review: Reject unless external context ties these labels to the same entity.
- Review: Spot-check the top-scoring pair before closing the whole group.

## Sample 12: f32
- Bucket: likely-reject
- Flags: has-low-specificity-labels, all-zero-overlap
- Labels: Distributed performance control system architecture, F32, Rust
- Review IDs: federated-entity-alias-claude-history-memory-entity-f32-claude-local-session-memory-entity-distributed, federated-entity-alias-claude-history-memory-entity-f32-claude-local-session-memory-entity-rust
- Example: F32 <> Distributed performance control system architecture [disjoint] score=0.83
- Proposed outcome: reject
- Manual outcome: 
- Notes: 
- Review: Reject unless external context ties these labels to the same entity.
- Review: Spot-check the top-scoring pair before closing the whole group.
- Review: Verify labels are not headings, placeholders, fragments, or extraction residue.
