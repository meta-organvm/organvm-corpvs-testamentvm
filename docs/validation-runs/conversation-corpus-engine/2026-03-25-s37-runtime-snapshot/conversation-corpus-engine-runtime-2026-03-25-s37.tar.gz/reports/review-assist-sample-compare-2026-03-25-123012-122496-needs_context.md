Entity-alias review sample comparison
Sample: campaign:needs_context:sample
Proposal: campaign:needs_context:proposal
Matched: 8  Adjudicated: 0  Comparable: 0
Agreement: 0  Disagreement: 0  Agreement rate: n/a
Proposal reject precision: n/a
Proposal rejects: 0  Hits: 0  False positives: 0
Confidence: medium=8
