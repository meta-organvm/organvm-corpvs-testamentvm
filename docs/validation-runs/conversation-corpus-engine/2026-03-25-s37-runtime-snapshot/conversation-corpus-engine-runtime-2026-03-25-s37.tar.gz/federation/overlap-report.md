# Federated Overlap Report

- Generated: 2026-03-25T17:35:56.047954+00:00
- Canonical entities: 0
- Canonical families: 0
- Canonical actions: 0
- Canonical unresolved: 0
- Open review items: 0
- Potential conflicts: 0

## Open Review Types

No open federated review items.
