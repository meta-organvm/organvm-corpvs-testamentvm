# Conversation Corpus Federation Summary

- Generated: 2026-03-25T17:35:56.052424+00:00
- Corpus count: 5
- Healthy corpus count: 0
- Managed corpus count: 0
- Fresh corpus count: 0
- Stale corpus count: 0
- Missing snapshot count: 0
- Missing source count: 0
- Thread count: 0
- Family count: 0
- Action count: 0
- Unresolved count: 0
- Entity count: 0

## Corpora

- Ai Exports Markdown Memory (ai-exports-markdown-memory): threads=0, families=0, actions=0, unresolved=0, entities=0, adapter=unknown, gate=unknown, freshness=not_applicable, default=False
  missing=corpus/threads-index.json, corpus/semantic-v3-index.json, corpus/pairs-index.json, corpus/doctrine-briefs.json, corpus/family-dossiers.json
- Brainstorm Transcript Memory (brainstorm-transcript-memory): threads=0, families=0, actions=0, unresolved=0, entities=0, adapter=unknown, gate=unknown, freshness=not_applicable, default=False
  missing=corpus/threads-index.json, corpus/semantic-v3-index.json, corpus/pairs-index.json, corpus/doctrine-briefs.json, corpus/family-dossiers.json
- Chatgpt History (chatgpt-history): threads=0, families=0, actions=0, unresolved=0, entities=0, adapter=unknown, gate=unknown, freshness=not_applicable, default=True
  missing=corpus/threads-index.json, corpus/semantic-v3-index.json, corpus/pairs-index.json, corpus/doctrine-briefs.json, corpus/family-dossiers.json
- Claude History Memory (claude-history-memory): threads=0, families=0, actions=0, unresolved=0, entities=0, adapter=unknown, gate=unknown, freshness=not_applicable, default=False
  missing=corpus/threads-index.json, corpus/semantic-v3-index.json, corpus/pairs-index.json, corpus/doctrine-briefs.json, corpus/family-dossiers.json
- Claude Local Session Memory (claude-local-session-memory): threads=0, families=0, actions=0, unresolved=0, entities=0, adapter=unknown, gate=unknown, freshness=not_applicable, default=False
  missing=corpus/threads-index.json, corpus/semantic-v3-index.json, corpus/pairs-index.json, corpus/doctrine-briefs.json, corpus/family-dossiers.json
